<?php
if(!isset($_GET['f']) || empty($_GET['f'])){
	$form=1;
}else{
	$form=$_GET['f'];
}
if($form==1){
	global $wpdb;
	$khach_hang = $_GET['khach_hang'];
	$thang = $_GET['thang'];
	$nam = $_GET['nam'];
	$temp=$wpdb->get_results("
		SELECT
				ma_van_chuyen as id, 
				@curRank := @curRank + 1 AS stt,
				date_format(ngay, \"%d\") as ngay,
				ma_dich_vu,
				ma_tinh_den,
				khoi_luong,
				cuoc_phi,
				phu_thu,
				tong,
				ghi_chu,
				so_bill
				from gia_van_chuyen_dn, (SELECT @curRank := 0) r
				where date_format(ngay, \"%Y-%m\") = '$nam-$thang' and ma_khach_hang = '$khach_hang'
				order by ngay
	");
	$html_content=pack("CCC",0xef,0xbb,0xbf)."
		Header ở đây
		<table border=\"1\">
			<tr bgcolor=\"#cccccc\">
				<th>Ngày</th>
				<th>Mã dịch vụ</th>
				<th>Tỉnh đến</th>
				<th>Khối lượng</th>
				<th>Giá cước</th>
				<th>Phụ thu</th>
				<th>Tổng</th>
			</tr>
	";
	foreach($temp as $temp2){
		$html_content.="
			<tr>
				<td>".($temp2->ngay)."/$thang/$nam</td>
				<td>".($temp2->ma_dich_vu)."</td>
				<td>".($temp2->ma_tinh_den)."</td>
				<td>".($temp2->khoi_luong)."</td>
				<td>".($temp2->cuoc_phi)."</td>
				<td>".($temp2->phu_thu)."</td>
				<td>".($temp2->tong)."</td>
			</tr>
		";
		
	}
	$html_content.="
		</table>
		Footer ở đây
		";
	//$handle = fopen("../report/".$_GET['khach_hang']."_".$nam."_".$thang.".html", "w");
	//fputs($handle, $html_content);
	//fclose($handle);
	require('htmlpdf/html2fpdf.php');
	$pdf=new HTML2FPDF();
	$pdf->AddPage();
	//$fp = fopen("../report/".$_GET['khach_hang']."_".$nam."_".$thang.".html","r");
	//$strContent = fread($fp, filesize("../report/".$_GET['khach_hang']."_".$nam."_".$thang.".html"));
	//fclose($fp);
	$pdf->WriteHTML($html_content);
	$pdf->Output("../report/".$_GET['khach_hang']."_".$nam."_".$thang.".pdf");
	header("Location: ../report/".$_GET['khach_hang']."_".$nam."_".$thang.".pdf");
}